/* Continuous authored terrain for wilderness and dungeon floors.
   Unproject sprite materials once, blend in world coordinates, then seat each
   tile on its own elevation. Collision and cliff geometry remain authoritative. */
"use strict";
const LevelTerrain = (() => {
  const TILE=32, CHUNK=12, PAD=2, SIDE=(CHUNK+PAD*2)*TILE;
  const materials=new Map(),decalFrames=new Map(),chunks=new Map(),visible=new Set();
  const MIN_CAPACITY=40, RECENT_CHUNKS=12;
  let currentMap=null,chunkColumns=0,frameOpen=false,frame=0;
  let tileDraws=0,cacheHits=0,chunkBuilds=0,buildMs=0,evictions=0,capacity=MIN_CAPACITY;
  let totalBuilds=0,totalBuildMs=0,mapChanges=0;
  let surfacePolygons=[],surfaceIndex=null;
  const POLYGON_CELL=128;
  // The terraced floor is static. Keep its projected pixels, including cliffs
  // and rear rims, instead of resubmitting thousands of clipped tiles per tick.
  // Overscan lets the camera move normally without rebuilding the image.
  const VIEW_PAD=192;
  const MASSIF_THEMES=new Set(['snowwild','marsh','desert','hellwild','fields','forest']);
  const TERRAIN_GRIDS=['floor','walls','elev','hazard','scenicWater','void','cathedralMaterials'];
  const terrainGrid=(m,k)=>k==='scenicWater'?m.act2?.water:m[k];
  const terrainDecals=m=>m.cathedral?.decals||m.composition?.decals||m.act2?.decals||m.frontier?.decals||[];
  let terrainSnapshot=null;
  let surfaceView=null,surfaceViewBuilds=0,surfaceViewHits=0;
  let surfacePatch=null;
  const rearRimCache=new WeakMap();
  function release(key){const surface=chunks.get(key);chunks.delete(key);surface.width=surface.height=0;}
  function beginFrame(m){
    if(frameOpen)throw new Error('End the terrain frame before beginning another.');
    if(m!==currentMap){
      for(const key of chunks.keys())release(key);
      releaseSurfaceView();
      currentMap=m;chunkColumns=Math.ceil(m.w/CHUNK);mapChanges++;
    }
    // Terrain editing and fixtures can mutate byte grids in place. Compare
    // content so both the material chunks and projected pixels stay coherent.
    if(!sameTerrain(m)){
      for(const key of chunks.keys())release(key);
      releaseSurfaceView();
      chunkColumns=Math.ceil(m.w/CHUNK);
      terrainSnapshot={map:m,id:m.id,w:m.w,h:m.h,theme:m.zone?.theme,art:m.zone?.artZone,
        surfaceVersion:m.surfaceVersion,geometry:m._surfaceGeometry,outdoor:m.outdoor,decals:JSON.stringify(terrainDecals(m)),
        boundaries:m.boundaries,grids:TERRAIN_GRIDS.map(k=>terrainGrid(m,k)?.slice())};
    }
    visible.clear();surfacePolygons=[];surfaceIndex=null;frameOpen=true;frame++;
    tileDraws=cacheHits=chunkBuilds=buildMs=evictions=0;capacity=MIN_CAPACITY;
  }
  function sameTerrain(m){
    const s=terrainSnapshot;
    if(!s||s.boundaries!==m.boundaries||s.map!==m||s.id!==m.id||s.w!==m.w||s.h!==m.h||s.theme!==m.zone?.theme||s.art!==m.zone?.artZone||
       s.surfaceVersion!==m.surfaceVersion||s.geometry!==m._surfaceGeometry||s.outdoor!==m.outdoor||s.decals!==JSON.stringify(terrainDecals(m)))return false;
    for(let k=0;k<TERRAIN_GRIDS.length;k++){
      const a=s.grids[k],b=terrainGrid(m,TERRAIN_GRIDS[k]);
      if(a?.length!==b?.length)return false;
      if(a)for(let i=0;i<a.length;i++)if(a[i]!==b[i])return false;
    }
    return true;
  }
  function endFrame(){
    if(!frameOpen)return;
    // A fixed limit can be smaller than the viewport. Pin the entire frame's
    // working set, including later wall-cap draws, before evicting anything.
    capacity=Math.max(MIN_CAPACITY,visible.size+RECENT_CHUNKS);
    for(const key of chunks.keys()){
      if(chunks.size<=capacity)break;
      if(!visible.has(key)){release(key);evictions++;}
    }
    frameOpen=false;
  }
  function getDiagnostics(){
    // Immutable snapshot of the current/last frame. Build time is synchronous
    // canvas construction time, not GPU completion or total gameplay time.
    return Object.freeze({frame,mapId:currentMap?.id??null,frameOpen,tileDraws,cacheHits,chunkBuilds,buildMs,
      visibleChunks:visible.size,retainedChunks:chunks.size,capacity,evictions,totalBuilds,totalBuildMs,mapChanges,
      surfaceViewBuilds,surfaceViewHits,surfaceViewPixels:surfaceView?surfaceView.image.width*surfaceView.image.height:0});
  }
  function releaseSurfaceView(){
    if(surfaceView){surfaceView.image.width=surfaceView.image.height=0;surfaceView=null;}
    if(surfacePatch){surfacePatch.width=surfacePatch.height=0;surfacePatch=null;}
  }
  function canvas(w,h=w){const c=document.createElement('canvas');c.width=w;c.height=h;return c;}
  function material(id,index=0,trail=false,raw=false){
    const key=id+':'+index+':'+trail;if(materials.has(key))return materials.get(key);
    if(raw){
      const f=SpriteAssets.getFrame(id,0),size=320,overlap=64,period=size-overlap;
      const tile=canvas(size),t=tile.getContext('2d');
      t.translate(size/2,size/2);t.rotate(index*Math.PI/2);
      t.drawImage(f.image,f.sx,f.sy,f.sw,f.sh,-size/2,-size/2,size,size);t.resetTransform();
      // Overlap the source edges with complementary weights. This closes the
      // repeat in both axes without mirrored rocks, roots or snow patterns.
      const mask=canvas(size),p=mask.getContext('2d');
      for(const vertical of [false,true]){
        const ramp=p.createLinearGradient(0,0,vertical?0:size,vertical?size:0);
        ramp.addColorStop(0,'rgba(255,255,255,0)');ramp.addColorStop(overlap/size,'white');
        ramp.addColorStop(1-overlap/size,'white');ramp.addColorStop(1,'rgba(255,255,255,0)');
        p.globalCompositeOperation=vertical?'destination-in':'source-over';p.fillStyle=ramp;p.fillRect(0,0,size,size);
      }
      t.globalCompositeOperation='destination-in';t.drawImage(mask,0,0);
      const pattern=canvas(period),g=pattern.getContext('2d');g.globalCompositeOperation='lighter';
      for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++)g.drawImage(tile,x*period-overlap/2,y*period-overlap/2);
      materials.set(key,pattern);return pattern;
    }
    const f=SpriteAssets.getFrame(id,index),flat=canvas(64),g=flat.getContext('2d');
    g.setTransform(1,-1,2,2,-32,32);g.drawImage(f.image,f.sx,f.sy,f.sw,f.sh,0,0,64,32);
    // Crop inside the painted footprint so its old tile rim cannot repeat.
    const inset=trail?25:5,cut=flat.width-inset*2,size=trail?64:96;
    const pattern=canvas(size*2),p=pattern.getContext('2d');
    for(let y=0;y<2;y++)for(let x=0;x<2;x++){
      p.save();p.translate(x?size*2:0,y?size*2:0);p.scale(x?-1:1,y?-1:1);
      p.drawImage(flat,inset,inset,cut,cut,0,0,size,size);p.restore();
    }
    materials.set(key,pattern);return pattern;
  }
  function noise(x,y,salt){let h=Math.imul(x,73856093)^Math.imul(y,19349663)^Math.imul(salt,83492791);h=Math.imul(h^(h>>>16),0x45d9f3b);h=Math.imul(h^(h>>>16),0x45d9f3b);return ((h^(h>>>16))>>>0)/4294967295;}
  function fill(g,texture,ox,oy){
    g.save();g.translate(-ox,-oy);g.fillStyle=g.createPattern(texture,'repeat');g.fillRect(ox,oy,SIDE,SIDE);g.restore();
  }
  function masked(g,texture,mask,ox,oy,alpha){
    const layer=canvas(SIDE),p=layer.getContext('2d');fill(p,texture,ox,oy);
    p.globalCompositeOperation='destination-in';p.drawImage(mask,0,0);
    g.save();g.globalAlpha=alpha;g.drawImage(layer,0,0);g.restore();
  }
  function cellsMask(m,cx,cy,test,blur){
    const c=canvas(SIDE),g=c.getContext('2d');g.fillStyle='#fff';
    for(let y=-PAD;y<CHUNK+PAD;y++)for(let x=-PAD;x<CHUNK+PAD;x++){
      const wx=cx*CHUNK+x,wy=cy*CHUNK+y;
      if(wx>=0&&wy>=0&&wx<m.w&&wy<m.h&&test(wx+wy*m.w))g.fillRect((x+PAD)*TILE,(y+PAD)*TILE,TILE,TILE);
    }
    // Filter the union once; blurring individual cells leaves a darker grid
    // where their translucent edges meet inside a path or hazard pool.
    const soft=canvas(SIDE),p=soft.getContext('2d');p.filter='blur('+blur+'px)';p.drawImage(c,0,0);return soft;
  }
  function build(m,cx,cy){
    const surface=canvas(SIDE),g=surface.getContext('2d');
    const ox=(cx*CHUNK-PAD)*TILE,oy=(cy*CHUNK-PAD)*TILE,ground=SpriteAssets.maps.props[m.cathedral?m.cathedral.materials[m.cathedral.baseMaterial]:m.act3?.ground?'act3_ground_'+m.act3.ground:'level_ground_'+(m.zone.artZone||m.id)];
    fill(g,material(ground,0,false,true),ox,oy);
    // Overlapping soft patches break repetition without drawing a tile grid.
    for(let variant=1;variant<4;variant++){
      const mask=canvas(SIDE),p=mask.getContext('2d');
      for(let y=Math.floor(oy/192)-1;y<=Math.ceil((oy+SIDE)/192)+1;y++)for(let x=Math.floor(ox/192)-1;x<=Math.ceil((ox+SIDE)/192)+1;x++){
        if(1+Math.floor(noise(x,y,71)*3)!==variant)continue;
        const px=x*192+noise(x,y,13)*80-ox,py=y*192+noise(x,y,29)*80-oy,r=110+noise(x,y,47)*55;
        const grad=p.createRadialGradient(px,py,0,px,py,r);grad.addColorStop(0,'rgba(255,255,255,.72)');grad.addColorStop(1,'rgba(255,255,255,0)');
        p.fillStyle=grad;p.fillRect(px-r,py-r,r*2,r*2);
      }
      masked(g,material(ground,variant,false,true),mask,ox,oy,1);
    }
    if(m.cathedral)for(let mat=0;mat<4;mat++){
      if(mat===m.cathedral.baseMaterial)continue;
      const mask=cellsMask(m,cx,cy,i=>m.cathedralMaterials[i]===mat&&!m.void[i],12);
      masked(g,material(SpriteAssets.maps.props[m.cathedral.materials[mat]],0,false,true),mask,ox,oy,1);
    }
    const path=!m.cathedral&&SpriteAssets.maps.paths[m.zone.theme];
    if(path){
      const mask=cellsMask(m,cx,cy,i=>m.floor[i]>=4&&!m.walls[i]&&!m.act2?.water[i],m.composition||m.frontier||m.act2?18:9);
      const road=m.frontier&&m.id==='north_wild'?SpriteAssets.maps.props.frosthaven_street:null;
      masked(g,road?material(road,0,false,true):material(path,15,true),mask,ox,oy,m.composition||m.frontier||m.act2?.48:.86);
    }
    if(m.act3&&!m.outdoor&&!m.settlement){
      // Buried masonry reads as solid surrounding mass, distinct from streets.
      const cap=canvas(SIDE),p=cap.getContext('2d');
      fill(p,material(SpriteAssets.maps.props.act3_ground_tomb,0,false,true),ox,oy);
      p.fillStyle='rgba(12,16,19,.62)';p.fillRect(0,0,SIDE,SIDE);
      p.globalCompositeOperation='destination-in';p.drawImage(cellsMask(m,cx,cy,i=>!!m.walls[i],1),0,0);
      g.drawImage(cap,0,0);
    }
    if(m.act2){
      const water=SpriteAssets.maps.props.act2_black_water;
      masked(g,material(water,0,false,true),cellsMask(m,cx,cy,i=>!!m.act2.water[i],5),ox,oy,1);
    }
    const hazards=new Set();
    for(let y=Math.max(0,cy*CHUNK-PAD);y<Math.min(m.h,(cy+1)*CHUNK+PAD);y++)for(let x=Math.max(0,cx*CHUNK-PAD);x<Math.min(m.w,(cx+1)*CHUNK+PAD);x++)if(m.hazard?.[x+y*m.w])hazards.add(m.hazard[x+y*m.w]);
    for(const code of hazards){const def=DATA.HAZARDS[code],id=def&&SpriteAssets.maps.props['level_hazard_'+def.id];if(!id)continue;
      masked(g,material(id,0,false,true),cellsMask(m,cx,cy,i=>!m.walls[i]&&m.hazard[i]===code,6),ox,oy,.92);
    }
    for(const d of terrainDecals(m)){
      const x=d.x*TILE-ox,y=d.y*TILE-oy;
      if(x<-384||y<-384||x>SIDE+384||y>SIDE+384)continue;
      const id=SpriteAssets.maps.props[d.type];
      if(!decalFrames.has(id))decalFrames.set(id,SpriteAssets.getFrame(id,0));
      const f=decalFrames.get(id),s=d.scale||1;
      g.save();g.setTransform(.5,-.5,1,1,x,y);g.scale(d.turn?-s:s,s);g.globalAlpha=d.alpha??1;
      g.drawImage(f.image,f.sx,f.sy,f.sw,f.sh,-f.anchorX,-f.anchorY,f.sw,f.sh);g.restore();
    }
    return surface;
  }
  function tileTexture(m,x,y){
    if(!frameOpen||m!==currentMap)throw new Error('Call LevelTerrain.beginFrame(map) before drawing its tiles.');
    const cx=Math.floor(x/CHUNK),cy=Math.floor(y/CHUNK),key=cx+cy*chunkColumns;
    tileDraws++;
    let surface=chunks.get(key);
    if(!surface){
      const start=performance.now();surface=build(m,cx,cy);const elapsed=performance.now()-start;
      chunks.set(key,surface);chunkBuilds++;totalBuilds++;buildMs+=elapsed;totalBuildMs+=elapsed;
    }else{
      cacheHits++;
      // Repeated tiles in one chunk must not churn Map insertion order.
      if(!visible.has(key)){chunks.delete(key);chunks.set(key,surface);}
    }
    visible.add(key);
    const ux=(x-cx*CHUNK+PAD)*TILE,uy=(y-cy*CHUNK+PAD)*TILE;
    return {surface,ux,uy};
  }
  function drawTile(ctx,m,x,y,sx,sy){
    const {surface,ux,uy}=tileTexture(m,x,y);
    // Matching source/destination bleed seals fractional-camera joins while
    // preserving continuous UVs. The separate cliff pass keeps ledges sharp.
    ctx.save();ctx.transform(1,.5,-1,.5,sx,sy-16);
    ctx.drawImage(surface,ux-.5,uy-.5,33,33,-.5,-.5,33,33);ctx.restore();
  }
  function drawSurfaceTile(ctx,m,x,y,cam,geometryMap=m){
    const {surface,ux,uy}=tileTexture(m,x,y),[a,b,,d]=TerrainSurface.tileGeometry(geometryMap,x,y).top.points;
    ctx.save();
    ctx.transform((b.sx-a.sx)/TILE,(b.sy-a.sy)/TILE,(d.sx-a.sx)/TILE,(d.sy-a.sy)/TILE,a.sx-cam.x,a.sy-cam.y);
    ctx.drawImage(surface,ux-.5,uy-.5,33,33,-.5,-.5,33,33);
    ctx.restore();
  }
  function rearRims(m,x,y,geometry){
    if(rearRimCache.has(geometry))return rearRimCache.get(geometry);
    const rims=[],corners=geometry.top.points;
    // The camera cannot see these vertical faces. Expose a little rock on the
    // upper surface so the silhouette still reads as a drop into lower ground.
    for(const [a,b,nx,ny,ix,iy,facing] of [[corners[0],corners[3],x-1,y,1,0,0],[corners[0],corners[1],x,y-1,0,1,4]]){
      if(nx<0||ny<0)continue;
      const da=a.z-TerrainSurface.tileHeight(m,nx,ny,a.x,a.y),db=b.z-TerrainSurface.tileHeight(m,nx,ny,b.x,b.y);
      if(Math.max(da,db)<=1e-7)continue;
      let from=0,to=1;
      if(da<0)from=da/(da-db);else if(db<0)to=da/(da-db);
      const point=(t,width)=>{
        const fade=U.clamp(U.lerp(da,db,t)*2,0,1);
        const wx=U.lerp(a.x,b.x,t)+ix*width*fade,wy=U.lerp(a.y,b.y,t)+iy*width*fade;
        return {sx:U.isoX(wx,wy),sy:U.isoY(wx,wy)-TerrainSurface.tileHeight(m,x,y,wx,wy)*TerrainSurface.LIFT};
      };
      const outer=[point(from,0),point(to,0)],inner=[],shadow=[];
      for(let j=0;j<=6;j++){
        const t=U.lerp(from,to,j/6),wx=U.lerp(a.x,b.x,t),wy=U.lerp(a.y,b.y,t);
        const width=.16+.055*noise(Math.round(wx*24),Math.round(wy*24),91+facing);
        inner.push(point(t,width));shadow.push(point(t,width+.065));
      }
      rims.push({outer,inner,shadow,texture:[...outer,point(to,.23),point(from,.23)],facing});
    }
    rearRimCache.set(geometry,rims);return rims;
  }
  function drawRearRims(ctx,m,x,y,geometry,cam,cliffId){
    const rims=rearRims(m,x,y,geometry);if(!rims.length)return;
    const path=(points,close=false)=>{
      ctx.beginPath();ctx.moveTo(points[0].sx-cam.x,points[0].sy-cam.y);
      for(let i=1;i<points.length;i++)ctx.lineTo(points[i].sx-cam.x,points[i].sy-cam.y);
      if(close)ctx.closePath();
    };
    ctx.save();path(geometry.top.points,true);ctx.clip();ctx.lineJoin='round';
    for(const rim of rims){
      path([...rim.outer,...rim.shadow.slice().reverse()],true);ctx.fillStyle='rgba(8,18,27,.38)';ctx.fill();
      ctx.save();path([...rim.outer,...rim.inner.slice().reverse()],true);ctx.fillStyle='#263943';ctx.fill();ctx.clip();
      ctx.globalAlpha=.65;
      SpriteAssets.drawCliffPolygon(ctx,SpriteAssets.getFrame(cliffId,rim.facing+2),rim.texture,cam);
      ctx.restore();
      path(rim.outer);ctx.strokeStyle='rgba(7,16,24,.9)';ctx.lineWidth=1.5;ctx.stroke();
      path(rim.inner);ctx.strokeStyle='rgba(210,228,238,.68)';ctx.lineWidth=1;ctx.stroke();
    }
    ctx.restore();
  }
  function drawSurface(ctx,m,cam,x0,x1,y0,y1,inView,cacheView=false,damage=null){
    if(cacheView){drawSurfaceView(ctx,m,cam);return;}
    surfaceIndex=null;
    const tiles=[];
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++) {
      const sx=U.isoX(x+.5,y+.5)-cam.x,sy=U.isoY(x+.5,y+.5)-cam.y;
      if(!inView(sx,sy-TerrainSurface.heightAt(m,x+.5,y+.5)*14))continue;
      const geometry=TerrainSurface.tileGeometry(m,x,y);
      const paint=!damage||damage.some(r=>sx+34>r.x&&sx-34<r.x+r.w&&sy+18>r.y&&
        sy-(m._navMaxHeight??6)*TerrainSurface.LIFT-18<r.y+r.h);
      tiles.push({x,y,geometry,paint});
      // Backdrop-proof foundation is drawn before all elevated surfaces.
      if(paint&&geometry.top.points.some(p=>p.z>0))drawTile(ctx,m,x,y,sx,sy);
    }
    tiles.sort((a,b)=>a.x+a.y-b.x-b.y||a.y-b.y);
    const cliffId=SpriteAssets.maps.cliffs[m.zone.theme]||SpriteAssets.maps.cliffs.fields;
    for(const {x,y,geometry:g,paint} of tiles) {
      for(const face of g.faces) {
        if(paint){
          const max=Math.max(...face.points.map(p=>p.z)),min=Math.min(...face.points.map(p=>p.z));
          const frame=SpriteAssets.getFrame(cliffId,face.facing+U.clamp(Math.ceil(max-min),1,4)-1);
          SpriteAssets.drawCliffPolygon(ctx,frame,face.points,cam);
        }
        surfacePolygons.push(face);
      }
      if(paint){drawSurfaceTile(ctx,m,x,y,cam);drawRearRims(ctx,m,x,y,g,cam,cliffId);}
      surfacePolygons.push(g.top);
    }
    if(m.boundaries)Act2Boundaries.drawGround(ctx,m,cam,inView,damage);
  }
  // Historical stepped floors retain their exact foundation/cliff paint order.
  function drawFloor(ctx,m,cam,tx0,tx1,ty0,ty1,inView,cacheView=true,damage=null){
    if(cacheView){drawSurfaceView(ctx,m,cam,true);return;}
    const theme=m.zone.theme,ev=m.elev,EH=14;
    const massifTerrain=m.outdoor&&MASSIF_THEMES.has(theme);
    if(damage){
      const visible=inView;
      inView=(sx,sy)=>visible(sx,sy)&&damage.some(r=>sx+34>r.x&&sx-34<r.x+r.w&&sy+EH*6+18>r.y&&sy-EH*6-18<r.y+r.h);
    }
    if(m.cathedral){
      const f=SpriteAssets.getFrame(SpriteAssets.maps.props.cathedral_foundation,0);
      // Clip authored foundations to the actual exposed faces. Back corners of
      // a complete block must not protrude through a neighboring floor tile.
      for(let y=ty0;y<=ty1;y++)for(let x=tx0;x<=tx1;x++){
        const i=x+y*m.w;if(m.void[i]||!(m.void[i+1]||m.void[i+m.w]))continue;
        const sx=U.isoX(x+.5,y+.5)-cam.x,sy=U.isoY(x+.5,y+.5)-cam.y;if(!inView(sx,sy))continue;
        ctx.save();ctx.beginPath();
        if(m.void[i+m.w]){ctx.moveTo(sx-32,sy);ctx.lineTo(sx,sy+16);ctx.lineTo(sx,sy+52);ctx.lineTo(sx-32,sy+36);ctx.closePath();}
        if(m.void[i+1]){ctx.moveTo(sx,sy+16);ctx.lineTo(sx+32,sy);ctx.lineTo(sx+32,sy+36);ctx.lineTo(sx,sy+52);ctx.closePath();}
        ctx.clip();SpriteAssets.drawFrame(ctx,f,sx,sy);ctx.restore();
      }
    }
    /* Solid ground must continue underneath walls and raised terrain. Wall
       and cliff sprites have transparent edges; without this foundation those
       edges expose the screen-space backdrop instead of the level's floor.
       Draw foundations first so they cannot cover a neighboring raised face. */
    for (let y = ty0; !m.settlement && !m.surfaceVersion && y <= ty1; y++) {
      for (let x = tx0; x <= tx1; x++) {
        const i = x + y * m.w;
        // Flat open ground and outdoor wall caps already get a floor below.
        if (m.void?.[i] || (!(ev && ev[i]) && (!m.walls[i] || massifTerrain))) continue;
        const sx = U.isoX(x + 0.5, y + 0.5) - cam.x;
        const sy = U.isoY(x + 0.5, y + 0.5) - cam.y;
        if (inView(sx, sy)) drawTile(ctx,m,x,y,sx,sy);
      }
    }
    for (let y = ty0; !m.settlement && !m.surfaceVersion && y <= ty1; y++) {
      for (let x = tx0; x <= tx1; x++) {
        const i = x + y * m.w;
        const blocked = !!m.walls[i];
        /* Outdoor wall blobs are authored as snow/rock terrain topped by sparse
           boundary massifs. Keep a ground cap beneath every blocked tile so the
           culled interior cannot expose backdrop-colored diamond holes. */
        if (blocked && !massifTerrain) continue;
        const sx = U.isoX(x + 0.5, y + 0.5) - cam.x;
        const eh = (ev ? ev[i] : 0) * EH, sy = U.isoY(x + 0.5, y + 0.5) - cam.y - eh;
        if (!inView(sx, sy)) continue;
        if (eh) {
          const lD = (ev[i] - (y + 1 < m.h ? ev[i + m.w] : 0)) * EH;   // left/SW face
          const rD = (ev[i] - (x + 1 < m.w ? ev[i + 1] : 0)) * EH;     // right/SE face
          const cliffId = SpriteAssets.maps.cliffs[theme] || SpriteAssets.maps.cliffs.fields;
          /* Cliff cells are half-diamond faces rooted at their upper corner,
             while (sx,sy) is the raised tile center.  Seat the y+1/SW face on
             the tile's left vertex and the x+1/SE face on its right vertex;
             drawing both at center creates the detached wavy ribbons that cut
             across Fallen North plateaus. */
          if (lD > 0) SpriteAssets.drawCliff(ctx,
            SpriteAssets.getFrame(cliffId, 4 + U.clamp(Math.ceil(lD / EH), 1, 4) - 1), sx - 32, sy, lD);
          if (rD > 0) {
            SpriteAssets.drawCliff(ctx,
              SpriteAssets.getFrame(cliffId, U.clamp(Math.ceil(rD / EH), 1, 4) - 1), sx + 32, sy, rD);
          }
        }
        drawTile(ctx,m,x,y,sx,sy);
      }
    }

  }
  function drawSurfaceView(ctx,m,cam,legacy=false){
    const w=ctx.canvas.width,h=ctx.canvas.height;
    let entry=surfaceView;
    const compatible=entry&&entry.map===m&&entry.geometry===m._surfaceGeometry&&entry.legacy===legacy&&entry.w===w&&entry.h===h;
    if(!compatible||
       cam.x<entry.x||cam.y<entry.y||cam.x+w>entry.x+entry.image.width||cam.y+h>entry.y+entry.image.height){
      if(!compatible)releaseSurfaceView();
      const image=compatible?entry.image:canvas(w+VIEW_PAD*2,h+VIEW_PAD*2),g=image.getContext('2d');
      const origin={x:Math.floor(cam.x)-VIEW_PAD,y:Math.floor(cam.y)-VIEW_PAD};
      let damage=null;
      if(compatible){
        const dx=entry.x-origin.x,dy=entry.y-origin.y;
        if(Math.abs(dx)<image.width&&Math.abs(dy)<image.height){
          // Canvas self-copy snapshots the old pixels before moving them.
          // Integer offsets retain their sharpness; copy also clears the newly
          // exposed area. Repaint that area in the usual terrain depth order.
          g.globalCompositeOperation='copy';g.drawImage(image,dx,dy);g.globalCompositeOperation='source-over';
          damage=[];
          if(dx)damage.push({x:dx>0?0:image.width+dx,y:0,w:Math.abs(dx),h:image.height});
          if(dy)damage.push({x:0,y:dy>0?0:image.height+dy,w:image.width,h:Math.abs(dy)});
        }else g.clearRect(0,0,image.width,image.height);
      }
      const margin=96,pad=margin+SpriteAssets.WALL_VIEW_H+TerrainSurface.LIFT*6;
      const u0=(origin.x-margin)/32,u1=(origin.x+image.width+margin)/32;
      const v0=(origin.y-pad)/16,v1=(origin.y+image.height+pad)/16;
      const x0=Math.max(0,Math.floor((u0+v0)/2)-2),x1=Math.min(m.w-1,Math.ceil((u1+v1)/2)+2);
      const y0=Math.max(0,Math.floor((v0-u1)/2)-2),y1=Math.min(m.h-1,Math.ceil((v1-u0)/2)+2);
      const inView=(sx,sy)=>sx>-margin&&sx<image.width+margin&&sy>-margin-SpriteAssets.WALL_VIEW_H&&sy<image.height+margin;
      surfacePolygons=[];
      if(damage){
        // Keep the expensive tile/cliff raster work on a narrow surface. A
        // viewport-sized canvas with a damage clip still made Chrome's GPU
        // rasterizer stall for hundreds of milliseconds on 4K scrolls.
        for(const r of damage){
          const border=2,pw=r.w+border*2,ph=r.h+border*2;
          const patch=surfacePatch||(surfacePatch=canvas(pw,ph));
          if(patch.width!==pw)patch.width=pw;
          if(patch.height!==ph)patch.height=ph;
          const p=patch.getContext('2d');
          p.clearRect(0,0,pw,ph);
          const visible=(sx,sy)=>sx>r.x-border-margin&&sx<r.x+pw+margin&&
            sy>r.y-border-margin-SpriteAssets.WALL_VIEW_H&&sy<r.y+ph+margin;
          const patchDamage=[{x:r.x-border,y:r.y-border,w:pw,h:ph}];
          // Preserve the original camera arithmetic for cliff triangles;
          // changing their local coordinates introduces raster rounding drift.
          p.save();p.translate(border-r.x,border-r.y);
          if(legacy)drawFloor(p,m,origin,x0,x1,y0,y1,visible,false,patchDamage);
          else drawSurface(p,m,origin,x0,x1,y0,y1,visible,false,patchDamage);
          p.restore();
          // Replace, rather than blend, so transparent map edges and the
          // overlap of horizontal/vertical strips retain canonical alpha.
          g.clearRect(r.x,r.y,r.w,r.h);
          g.drawImage(patch,border,border,r.w,r.h,r.x,r.y,r.w,r.h);
        }
        // Occlusion needs all visible geometry, including unchanged pixels.
        // An empty damage list gathers that geometry without submitting art.
        surfacePolygons=[];
        if(!legacy)drawSurface(g,m,origin,x0,x1,y0,y1,inView,false,[]);
      }else{
        if(legacy)drawFloor(g,m,origin,x0,x1,y0,y1,inView,false);
        else drawSurface(g,m,origin,x0,x1,y0,y1,inView,false);
      }
      entry=surfaceView={image,map:m,geometry:m._surfaceGeometry,legacy,w,h,...origin,polygons:surfacePolygons,index:indexPolygons(surfacePolygons)};
      surfaceViewBuilds++;
    }else surfaceViewHits++;
    surfacePolygons=entry.polygons;
    surfaceIndex=entry.index;
    ctx.drawImage(entry.image,entry.x-cam.x,entry.y-cam.y);
  }
  function indexPolygons(polygons){
    const cells=new Map();
    for(let i=0;i<polygons.length;i++){
      const p=polygons[i];
      for(let y=Math.floor(p.top/POLYGON_CELL);y<=Math.floor(p.bottom/POLYGON_CELL);y++)
        for(let x=Math.floor(p.left/POLYGON_CELL);x<=Math.floor(p.right/POLYGON_CELL);x++){
          const key=x+':'+y;let list=cells.get(key);if(!list)cells.set(key,list=[]);list.push(i);
        }
    }
    return {cells,seen:new Uint32Array(polygons.length),stamp:0};
  }
  function nearbyPolygons(sx,sy){
    if(!surfaceIndex)return surfacePolygons;
    const index=surfaceIndex,ids=[];
    if(++index.stamp===0xffffffff){index.seen.fill(0);index.stamp=1;}
    for(let y=Math.floor((sy-252)/POLYGON_CELL);y<=Math.floor((sy+68)/POLYGON_CELL);y++)
      for(let x=Math.floor((sx-160)/POLYGON_CELL);x<=Math.floor((sx+160)/POLYGON_CELL);x++){
        for(const id of index.cells.get(x+':'+y)||[]){
          if(index.seen[id]===index.stamp)continue;index.seen[id]=index.stamp;ids.push(id);
        }
      }
    // Retain the original clipping order and apply each polygon only once,
    // even when it straddles multiple spatial cells.
    ids.sort((a,b)=>a-b);return ids.map(id=>surfacePolygons[id]);
  }
  function clipBehind(ctx,m,cam,x,y,surfaceId=0){
    if(!m.surfaceVersion)return;
    const sx=U.isoX(x,y),sy=U.isoY(x,y)-TerrainSurface.heightAt(m,x,y,surfaceId)*14,h=TerrainSurface.heightAt(m,x,y,surfaceId);
    for(const poly of nearbyPolygons(sx,sy)) {
      if(poly.right<sx-160||poly.left>sx+160||poly.bottom<sy-252||poly.top>sy+68||!poly.points.some(p=>p.z>h+1e-7))continue;
      if(poly.kind==='ground'&&poly.tx===Math.floor(x)&&poly.ty===Math.floor(y))continue;
      const points=TerrainSurface.inFront(poly,x+y);
      if(points.length<3)continue;
      // Intersect complements individually: overlapping faces must stay hidden,
      // whereas one combined even-odd path would expose their intersections.
      ctx.beginPath();ctx.rect(0,0,ctx.canvas.width,ctx.canvas.height);
      ctx.moveTo(points[0].sx-cam.x,points[0].sy-cam.y);
      for(let i=1;i<points.length;i++)ctx.lineTo(points[i].sx-cam.x,points[i].sy-cam.y);
      ctx.closePath();ctx.clip('evenodd');
    }
  }
  return Object.freeze({beginFrame,drawTile,drawSurfaceTile,drawSurface,drawFloor,clipBehind,endFrame,getDiagnostics});
})();

/* Act II uses complete painted modules along classified collision contours.
   Ground lips are painted into LevelTerrain's cached surface. Upright modules
   share the actor draw list and fade without changing their solid footprint. */
const Act2Boundaries=(()=>{
  const cache=new WeakMap();
  function assembly(m){
    let saved=cache.get(m.boundaries);if(saved)return saved;
    saved=m.boundaries.segments.map(s=>{
      const kit=s.kit;
      const direction=s.axis?'south':'east';
      // Some generated alternates include taller reeds; keep the low mud lip
      // on the terrain layer and retain complete pieces at the visible scale.
      const part=kit==='masonry'&&s.variant===4&&s.length===3&&!s.axis&&m.id!=='drowned_crypt'?'broken_east':
        kit==='root'&&s.variant===4?'end_'+direction:direction+(s.variant===1||kit==='shore'&&s.axis?'_alt':'');
      const key=kit+'_'+part;
      const f=SpriteAssets.getFrame(SpriteAssets.maps.props['a2boundary_'+key],0);
      const x=s.x+(s.axis?0:s.length/2),y=s.y+(s.axis?s.length/2:0);
      const fx=s.x+(s.axis?0:1.5),fy=s.y+(s.axis?1.5:0);
      return {kind:'act2Boundary',d:x+y+.02,x,y,s,f,wx:U.isoX(fx,fy),wy:U.isoY(fx,fy),cx:U.isoX(x,y),cy:U.isoY(x,y)};
    });
    saved.sort((a,b)=>a.d-b.d);
    saved.banks=[];
    const f=SpriteAssets.getFrame(SpriteAssets.maps.props.a2boundary_shore_east,0);
    for(const points of m.boundaries.shorelines)for(let i=1;i<points.length;i++){
      const a=points[i-1],b=points[i],ax=U.isoX(a.x,a.y),ay=U.isoY(a.x,a.y),bx=U.isoX(b.x,b.y),by=U.isoY(b.x,b.y);
      saved.banks.push({x:(ax+bx)/2,y:(ay+by)/2,length:Math.hypot(bx-ax,by-ay),angle:Math.atan2(by-ay,bx-ax),f});
    }
    // Sparse, upright growth sits on the blocked side, not on the walking lane.
    for(const s of m.boundaries.segments)if(s.kit==='shore'&&s.length>=2&&((s.x*7+s.y*13)%11===0)){
      const x=s.x+(s.axis?s.side*.7:s.length/2),y=s.y+(s.axis?s.length/2:s.side*.7);
      const f=SpriteAssets.getFrame(SpriteAssets.maps.props.act2_reed_clump,0),scale=.32+((s.x+s.y)%3)*.06;
      saved.push({kind:'act2Boundary',d:x+y,x,y,s:{...s,kit:'growth'},f,scale,wx:U.isoX(x,y),wy:U.isoY(x,y),cx:U.isoX(x,y),cy:U.isoY(x,y)});
    }
    cache.set(m.boundaries,saved);return saved;
  }
  function paint(ctx,d){
    const {s,f,sx,sy}=d;
    if(d.scale){ctx.drawImage(f.image,f.sx,f.sy,f.sw,f.sh,sx-f.anchorX*d.scale,sy-f.anchorY*d.scale,f.sw*d.scale,f.sh*d.scale);return;}
    // These static sprites need only a rectangular source crop. Submit that
    // rectangle directly instead of saving/translating/clipping for every wall.
    const left=Math.max(0,d.centerX-sx-s.length*16-6+f.anchorX);
    const right=Math.min(f.sw,d.centerX-sx+s.length*16+6+f.anchorX),width=right-left,height=Math.min(f.sh,f.anchorY+40);
    if(width>0)ctx.drawImage(f.image,f.sx+left,f.sy,width,height,sx-f.anchorX+left,sy-f.anchorY,width,height);
  }
  function drawGround(ctx,m,cam,inView,damage=null){
    if(damage&&damage.length===0)return;
    for(const d of assembly(m).banks){
      const x=d.x-cam.x,y=d.y-cam.y;
      if(!inView(x,y))continue;
      if(damage&&!damage.some(r=>x+80>r.x&&x-80<r.x+r.w&&y+80>r.y&&y-80<r.y+r.h))continue;
      ctx.save();ctx.translate(x,y);ctx.rotate(d.angle);ctx.beginPath();ctx.rect(-d.length/2-1,-24,d.length+2,48);ctx.clip();
      // Rotate the flat decal to the contour tangent, without deforming it.
      ctx.rotate(-Math.atan2(221,278));ctx.globalAlpha=.76;SpriteAssets.drawFrame(ctx,d.f,0,0);ctx.restore();
    }
  }
  function append(draws,m,cam,player,W,H){
    for(const d of assembly(m)){
      if(d.s.kit==='shore')continue;
      d.sx=d.wx-cam.x;d.sy=d.wy-cam.y;d.centerX=d.cx-cam.x;
      const f=d.f;
      if(d.sx-f.anchorX>W||d.sx-f.anchorX+f.sw<0||d.sy-f.anchorY>H||d.sy-f.anchorY+f.sh<0)continue;
      d.hx=U.isoX(player.x,player.y)-cam.x;d.hy=U.isoY(player.x,player.y)-cam.y;
      draws.push(d);
    }
  }
  function draw(ctx,d,player){
    const alpha=ctx.globalAlpha;
    if(player.x+player.y<d.d+.5&&Math.abs(d.hx-d.centerX)<d.s.length*16+22&&d.hy>d.sy-d.f.anchorY-12&&d.hy<d.sy+20)ctx.globalAlpha=alpha*.24;
    paint(ctx,d);ctx.globalAlpha=alpha;
  }
  return Object.freeze({drawGround,append,draw});
})();

/* Painted masonry is depth-sorted with actors. Decks are separate surfaces,
   never solid cliff columns, so the route beneath stays visible and usable. */
const ImperialArchitecture=(()=>{
  const frame=key=>SpriteAssets.getFrame(SpriteAssets.maps.props['act3_arch_'+key],0);
  const planes=new WeakMap(),assemblies=new WeakMap();
  function assembly(m){
    const key=m._surfaceGeometry;
    let cached=assemblies.get(key);if(cached)return cached;
    const art=m.act3.architecture;
    const walls=art.walls.map(wall=>{
      const x=wall.x+(wall.axis?0:wall.length/2),y=wall.y+(wall.axis?wall.length/2:0);
      const a=TerrainSurface.heightAt(m,wall.x-.01,wall.y-.01,0),b=TerrainSurface.heightAt(m,wall.x+.01,wall.y+.01,0);
      return {kind:'imperialWall',d:x+y,wx:U.isoX(x,y),wy:U.isoY(x,y)-Math.min(a,b)*14,wall,kit:wall.kit||(m.outdoor?'rock':art.kit)};
    });
    const sockets=new Map();
    for(const d of walls)if(d.kit!=='rock'){
      const w=d.wall;
      for(const [x,y] of [[w.x,w.y],[w.x+(w.axis?0:w.length),w.y+(w.axis?w.length:0)]]){
        const key=x+':'+y;let n=sockets.get(key);
        if(!n)sockets.set(key,n={x,y,kit:d.kit,axes:new Set()});n.axes.add(w.axis);
      }
    }
    for(const n of sockets.values())if(n.axes.size===2){
      const z=Math.min(...[-.01,.01].flatMap(dx=>[-.01,.01].map(dy=>TerrainSurface.heightAt(m,n.x+dx,n.y+dy,0))));
      walls.push({kind:'imperialCap',d:n.x+n.y+.01,wx:U.isoX(n.x,n.y),wy:U.isoY(n.x,n.y)-z*14,kit:n.kit,wall:{length:1}});
    }
    const bridges=[...art.bridges,...(art.terraces||[])].map(bridge=>{
      const v=bridge.terrace?m:m.layers[1],rails=[],supports=[];
      for(const x of bridge.terrace?[]:[bridge.x-4.5,bridge.x+6.5])for(const y of [bridge.y0+.5,bridge.y1-.5])
        supports.push({kind:'imperialSupport',d:x+y,x,y,wx:U.isoX(x,y),wy:U.isoY(x,y)});
      for(let x=bridge.lo+1.5;x<bridge.hi-1.5;x+=1.5)for(const y of [bridge.y0,bridge.y1]){
        const z=TerrainSurface.heightAt(v,x,Math.min(bridge.y1-.01,Math.max(bridge.y0+.01,y)));
        rails.push({kind:'imperialRail',d:x+y,x,y,wx:U.isoX(x,y),wy:U.isoY(x,y)-z*14});
      }
      return {bridge,rails,supports};
    });
    cached={walls,bridges};assemblies.set(key,cached);return cached;
  }
  function plane(m,bridge){
    const v=bridge.terrace?m:m.layers[1],key=v._surfaceGeometry;
    let cached=planes.get(key);if(cached)return cached;
    const cells=[];let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
    for(let y=bridge.y0;y<bridge.y1;y++)for(let x=bridge.lo;x<bridge.hi;x++){
      const g=TerrainSurface.tileGeometry(v,x,y);cells.push({kind:'imperialDeck',x,y,g,bridge,under:false});
      for(const p of g.top.points){left=Math.min(left,p.sx);right=Math.max(right,p.sx);top=Math.min(top,p.sy);bottom=Math.max(bottom,p.sy+8);}
    }
    left=Math.floor(left)-2;top=Math.floor(top)-2;
    const image=document.createElement('canvas');image.width=Math.ceil(right-left)+4;image.height=Math.ceil(bottom-top)+4;
    const ctx=image.getContext('2d'),cam={x:left,y:top};
    cells.sort((a,b)=>a.x+a.y-b.x-b.y);for(const cell of cells)draw(ctx,cell,m,cam,{});
    cached={image,left,top};planes.set(key,cached);return cached;
  }
  function append(draws,m,cam,player,W,H){
    const art=assembly(m);
    const hx=U.isoX(player.x,player.y)-cam.x,hy=U.isoY(player.x,player.y)-cam.y-TerrainSurface.heightAt(m,player.x,player.y,player.surfaceId)*14;
    for(const d of art.walls){
      const {wall}=d,sx=d.wx-cam.x,sy=d.wy-cam.y;
      if(sx< -180||sx>W+180||sy< -50||sy>H+180)continue;
      d.sx=sx;d.sy=sy;d.hx=hx;d.hy=hy;draws.push(d);
    }
    for(const {bridge,rails,supports} of art.bridges){
      const under=!bridge.terrace&&player.surfaceId!==1&&player.x>=bridge.lo&&player.x<bridge.hi&&player.y>bridge.y0-2&&player.y<bridge.y1+2;
      const cached=plane(m,bridge);
      if(cached.left-cam.x<W&&cached.left-cam.x+cached.image.width>0&&cached.top-cam.y<H&&cached.top-cam.y+cached.image.height>0)
        draws.push({kind:'imperialPlane',d:bridge.terrace?-Infinity:bridge.x+bridge.y,plane:cached,under,bridge});
      for(const list of [supports,rails])for(const d of list){
        d.sx=d.wx-cam.x;d.sy=d.wy-cam.y;d.under=under;
        if(d.sx>-100&&d.sx<W+100&&d.sy>-60&&d.sy<H+160)draws.push(d);
      }
    }
  }
  function draw(ctx,d,m,cam,player){
    ctx.save();
    if(d.kind==='imperialPlane'){
      if(d.under)ctx.globalAlpha=.18;
      ctx.drawImage(d.plane.image,d.plane.left-cam.x,d.plane.top-cam.y);
    }else if(d.kind==='imperialWall'){
      const w=d.wall,f=frame(d.kit+'_'+(w.broken?'broken':w.axis?'south':'east'));
      if(Math.abs(d.hx-d.sx)<w.length*32+24&&d.hy>d.sy-f.sh&&d.hy<d.sy+30&&player.x+player.y<d.d+1)ctx.globalAlpha=.24;
      // Crop short end runs; preserve the painting's scale and masonry size.
      const fullX=w.x+(w.axis?0:1.5),fullY=w.y+(w.axis?1.5:0),sx=U.isoX(fullX,fullY)-cam.x;
      const sy=d.sy+(3-w.length)*8;
      if(w.length<3){ctx.beginPath();ctx.rect(d.sx-w.length*16-9,d.sy-200,w.length*32+18,240);ctx.clip();}
      SpriteAssets.drawFrame(ctx,f,sx,sy+16);
    }else if(d.kind==='imperialCap'){
      if(Math.abs(d.hx-d.sx)<30&&d.hy>d.sy-75&&d.hy<d.sy+25&&player.x+player.y<d.d+1)ctx.globalAlpha=.24;
      SpriteAssets.drawFrame(ctx,frame(d.kit+'_pillar'),d.sx,d.sy+10,{scale:.55});
    }else if(d.kind==='imperialRail'){
      if(d.under)ctx.globalAlpha=.18;
      SpriteAssets.drawFrame(ctx,frame('bridge_parapet'),d.sx,d.sy+5,{scale:.55});
    }else if(d.kind==='imperialSupport'){
      const f=frame(m.act3.architecture.kit+'_pillar'),scale=112/(f.sh-8);
      SpriteAssets.drawFrame(ctx,f,d.sx,d.sy,{scale});
    }else{
      const v=d.bridge.terrace?m:m.layers[1],g=d.g,under=d.under;
      if(under)ctx.globalAlpha=.18;
      // Only the slab fascia is solid; nothing fills the space beneath it.
      const cliff=SpriteAssets.maps.cliffs[m.zone.theme]||SpriteAssets.maps.cliffs.fields;
      for(const [a,b,facing] of [[g.top.points[1],g.top.points[2],0],[g.top.points[3],g.top.points[2],4]]){
        const points=[a,b,{...b,sy:b.sy+7,z:b.z-.5},{...a,sy:a.sy+7,z:a.z-.5}];
        SpriteAssets.drawCliffPolygon(ctx,SpriteAssets.getFrame(cliff,facing),points,cam);
      }
      const f=frame('deckmaterial_material'),[a,b,,c]=g.top.points;
      ctx.transform((b.sx-a.sx)/64,(b.sy-a.sy)/64,(c.sx-a.sx)/64,(c.sy-a.sy)/64,a.sx-cam.x,a.sy-cam.y);
      ctx.drawImage(f.image,f.sx+(d.x%4)*64,f.sy+(d.y%2)*64,64,64,-.3,-.3,64.6,64.6);
    }
    ctx.restore();
  }
  return {append,draw};
})();
