Working-tree baseline immediately before the Act 2 normal/champion attack-radius visibility change. Includes existing animation work and unrelated changes.
